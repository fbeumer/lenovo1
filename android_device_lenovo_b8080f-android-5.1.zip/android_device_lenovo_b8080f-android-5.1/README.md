# Minimal Device Configuration

This is a minimal device configuration for TWRP on the Lenovo Yoga HD 10+ (Wi-Fi only)
tablet.

For the full device configuration (wip) please see the [cm-11.0][] branch.

<!-- Links -->
[cm-11.0]: https://github.com/kbehren/android_device_lenovo_b8080f/tree/cm-11.0
